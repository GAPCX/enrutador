(function () {
    angular.module("app.services", [])    
})();